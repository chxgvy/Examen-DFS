# Déploiement

## Réservation du nom de domaine

### Questions

1) Expliquer la procédure pour réserver un nom de domaine chez OVH avec des captures d'écran (arrêtez-vous au paiement) :

Rendez vous dans le dossier "Nom de domaine" juste au dessus dans l'arborescence, j'y ai ajouté les captures d'écrans


2. Comment faire pour qu'un nom de domaine pointe vers une adresse IP spécifique ?
Pour cela, nous devons créer un enregistrement DNS pour notre nom de domaine ainsi nous pourrons remplacer dans la section adresse, l'adresse IP vers laquelle le nom de domaine doit pointer.


## Préparation du VPS

Todo...
