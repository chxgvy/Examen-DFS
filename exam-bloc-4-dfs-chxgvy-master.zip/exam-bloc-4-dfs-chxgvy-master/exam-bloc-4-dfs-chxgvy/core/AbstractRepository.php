<?php
namespace Mns\Buggy\Core;

abstract class AbstractRepository
{   

/**
     * Cette méthode permet de se connecter
     *
     * @param  mixed getConnection
     * @param  mixed getInstance
     * @return MySqlConnector
     */

    public function getConnection() {
        return MySqlConnector::getInstance()->getConnection();
    }

/**
     * Cette méthode permet de se trouver
     *
     * @param  mixed findAll
     */

    public abstract function findAll();

/**
     * Cette méthode permet de se trouver
     *
     * @param mixed find
     * @param mixed $id
     */

    public abstract function find(int $id);
}