# Déploiement

## Réservation du nom de domaine

### Questions

1) Expliquer la procédure pour réserver un nom de domaine chez OVH avec des captures d'écran (arrêtez-vous au paiement) :

Rendez vous dans le dossier "Nom de domaine" juste au dessus dans l'arborescence, j'y ai ajouté les captures d'écrans
1- Dans la barre de recherche taper le nom de domaine que vous souhaitez ici dans l'exemple "charlizegevrey.fr et charlizegevrey.com", j'ai décidé de prendre les deux pour éviter de me faire copiwrite.
2- A votre droite vous avez un récapitulatif de votre panier et ce que vous avez sélectionnez ainsi qu'un DNS inclus.
3- Ensuite la page option, où vous choisissez ce que vous souhaitez ajouté à votre nom de domaine, ici j'ai décidé de prendre la version de base par exemple si je décide de créer un CV en ligne ou un portfolio.
4- Page récapitulative, voici un récapitulatif des noms de domaine sélectionnés, avec les DNS ainsi que notre offre d'hébergement, si tout vous convient...vous pouvez procéder au paiement.
5- Procédure de paiement.

2. Comment faire pour qu'un nom de domaine pointe vers une adresse IP spécifique ?

Pour cela, nous devons créer un enregistrement DNS pour notre nom de domaine ainsi nous pourrons remplacer dans la section adresse, l'adresse IP vers laquelle le nom de domaine doit pointer.


## Préparation du VPS

Pour installer aapanel 
Connectez-vous au serveur via SSH en tant qu'utilisateur "root" et mettre à jour le système actuel ;
apt-get update; apt upgrade -y
apt install wget -y

Téléchargez et exécutez le script d'installation :

cd /tmp && wget http://www.aapanel.com/script/install-ubuntu_6.0_en.sh
chmod +x install-ubuntu_6.0_en.sh
./install-ubuntu_6.0_en.sh aapanel

Le panneau propose de choisir l'un des ensembles de logiciels préinstallés. On choisit phpmyadmin, php, mysql, apache etc...