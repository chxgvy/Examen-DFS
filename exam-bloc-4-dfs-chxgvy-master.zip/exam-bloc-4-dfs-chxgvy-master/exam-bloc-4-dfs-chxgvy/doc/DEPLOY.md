# Déploiement

## Réservation du nom de domaine

### Questions

1) Expliquer la procédure pour réserver un nom de domaine chez OVH avec des captures d'écran (arrêtez-vous au paiement) :

Rendez vous dans le dossier "Nom de domaine" juste au dessus dans l'arborescence, j'y ai ajouté les captures d'écrans
1- Dans la barre de recherche taper le nom de domaine que vous souhaitez ici dans l'exemple "charlizegevrey.fr et charlizegevrey.com", j'ai décidé de prendre les deux pour éviter de me faire copiwrite.
2- A votre droite vous avez un récapitulatif de votre panier et ce que vous avez sélectionnez ainsi qu'un DNS inclus.
3- Ensuite la page option, où vous choisissez ce que vous souhaitez ajouté à votre nom de domaine, ici j'ai décidé de prendre la version de base par exemple si je décide de créer un CV en ligne ou un portfolio.
4- Page récapitulative, voici un récapitulatif des noms de domaine sélectionnés, avec les DNS ainsi que notre offre d'hébergement, si tout vous convient...vous pouvez procéder au paiement.
5- Procédure de paiement.

2. Comment faire pour qu'un nom de domaine pointe vers une adresse IP spécifique ?

Pour cela, nous devons créer un enregistrement DNS pour notre nom de domaine ainsi nous pourrons remplacer dans la section adresse, l'adresse IP vers laquelle le nom de domaine doit pointer.


## Préparation du VPS

Pour commencer, ouvrir le terminal et se connecter en root
"ssh root@172.16.1.206"
fingerprint - yes
Taper le mot de passe "6ibb938i"

Une fois connecté en root

URL=https://www.aapanel.com/script/install_7.0_en.sh && if [ -f /usr/bin/curl ];then curl -ksSO "$URL" ;else wget --no-check-certificate -O install_7.0_en.sh "$URL";fi;bash install_7.0_en.sh aapanel
Voulez vous installer aapanel "yes"
Une fois l'installation finie

cliquer sur l'adresse : https://172.16.1.206:31665/d94f9fd7
Connectez vous à l'interface aapanel grâce au nom d'utilisateur : "znfncwmf" et le mot de passe : "1b1d0260"
Vous arrivez sur le dashboard et sélectionner tous les logiciels recommandé
Attendez l'installation complète

Dans website créée un site internet en marquand l'adresse IP : 127.16.1.206

Dans le terminal cd / l'url
Afin de rédirigé l'url vers le navigateur