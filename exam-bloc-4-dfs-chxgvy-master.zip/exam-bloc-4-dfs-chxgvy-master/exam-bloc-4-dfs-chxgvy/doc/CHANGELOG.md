Added pour les nouvelles fonctionnalités.

Changed pour les changements aux fonctionnalités préexistantes.

Deprecated pour les fonctionnalités qui seront bientôt supprimées.

Removed pour les fonctionnalités désormais supprimées.

Fixed pour les corrections de bugs.

Security en cas de vulnérabilités.

--------------------------------------------------------------------------------------------------------------------------------

Lun 9 septembre 2024

Added - Fonction qui permet de vérifier si l'utilisateur est connecté
Added - htmlspecialchars pour éviter que les données fournies par les utilisateurs contiennent des balises html