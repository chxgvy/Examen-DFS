# TODOLIST

## BUGS

* Les utilisateurs peuvent se connecter sans mot de passe
* Des utilsateurs non admin ont des accès à l'interface de gestion des utilisateurs
* Problème de redirection après l'ajout d'un nouveau ticket
* Erreur au niveau de l'API

## FAILLES

Faire un audit des failles présentes dans l'application et fournir des préconisations pour chacune d'entre elles.

Proposer un correctif si cela est possible et le déployer.